# Storage Examples

Storage and management of user and system data in module’s flash and on external memory / devices.

See the [README.md](../README.md) file in the upper level [examples](../) directory for more information about examples.

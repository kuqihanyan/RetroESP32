This directory contains header-only version of Catch C++ unit test library,
mostly used in host-side tests.

See https://github.com/philsquared/catch for more info.

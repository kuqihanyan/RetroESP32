.. important::
   The following features are not yet supported with the CMake-based build system:

   - Eclipse IDE Documentation
   - Secure Boot
   - Flash Encryption

   Support for these features will be available before CMake becomes the default build system.


.. include:: /../en/cmake-pending-features.rst

.. include:: ../../en/get-started-cmake/establish-serial-connection.rst

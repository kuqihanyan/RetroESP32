.. include:: ../../en/get-started-cmake/idf-monitor.rst

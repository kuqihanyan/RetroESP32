.. include:: ../../en/get-started-cmake/toolchain-setup-scratch.rst

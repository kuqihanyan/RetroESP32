.. include:: ../../en/get-started-cmake/macos-setup.rst

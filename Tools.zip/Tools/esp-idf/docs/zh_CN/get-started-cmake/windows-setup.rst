.. include:: ../../en/get-started-cmake/windows-setup.rst

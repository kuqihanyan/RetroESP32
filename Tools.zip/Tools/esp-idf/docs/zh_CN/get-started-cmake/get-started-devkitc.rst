.. include:: ../../en/get-started-cmake/get-started-devkitc.rst
